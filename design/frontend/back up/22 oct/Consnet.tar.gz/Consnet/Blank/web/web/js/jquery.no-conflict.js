
define(['jQuery321'],function ()
{
    return jQuery.noConflict(true);
});
