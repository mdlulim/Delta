
var config = {
"paths":
{
    "jQuery321": "Magento_Theme/js/jquery-3.2.1.min",
    "jqueryNoConflict": "Magento_Theme/js/jquery.no-conflict",
    "bootstrap3" : "Magento_Theme/js/bootstrap.min",
    "main": "Magento_Theme/js/main",
    "jquery.dataTables.min": "Magento_Theme/js/jquery.dataTables.min",
    "dataTables.buttons.min": "Magento_Theme/js/dataTables.buttons.min",
    "buttons.flash.min": "Magento_Theme/js/buttons.flash.min",
    "jszip.min": "Magento_Theme/js/jszip.min",
    "pdfmake.min": "Magento_Theme/js/pdfmake.min",
    "vfs_fonts": "Magento_Theme/js/vfs_fonts",
    "buttons.html5.min": "Magento_Theme/js/buttons.html5.min",
    "buttons.print.min": "Magento_Theme/js/buttons.print.min"
} 
}; 
